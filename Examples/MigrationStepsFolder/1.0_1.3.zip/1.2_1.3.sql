PRINT 'add column'
GO

ALTER TABLE dbo.Demo ADD Column2 NVARCHAR(100) NULL
GO
