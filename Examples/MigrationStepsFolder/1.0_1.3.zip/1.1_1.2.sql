PRINT 'add column'
GO

ALTER TABLE dbo.Demo ADD Column1 NVARCHAR(100) NULL
GO
